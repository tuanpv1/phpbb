<?php
/**
*
* @package phpBB Extension - RH Topic Tags
* @copyright (c) 2014 Robet Heim
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace robertheim\topictags;

class tables
{
	const TAGS = 'rh_topictags_tag';
	const TOPICTAGS = 'rh_topictags';
}
